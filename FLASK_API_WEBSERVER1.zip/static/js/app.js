// API конфигурация
const API_URL = 'http://localhost:5000/api';

// Глобальные переменные
let currentToken = localStorage.getItem('token');
let currentUser = null;
let currentNote = null;
let allNotes = [];

// Инициализация приложения
document.addEventListener('DOMContentLoaded', () => {
    if (currentToken) {
        checkAuth();
    }
});

// Проверка авторизации
async function checkAuth() {
    try {
        const response = await fetch(`${API_URL}/me`, {
            headers: {
                'Authorization': `Bearer ${currentToken}`
            }
        });
        
        if (response.ok) {
            const user = await response.json();
            currentUser = user;
            showNotesApp();
            loadNotes();
        } else {
            showAuthForms();
        }
    } catch (error) {
        console.error('Auth check failed:', error);
        showAuthForms();
    }
}

// Показать формы авторизации
function showAuthForms() {
    document.getElementById('authForms').style.display = 'block';
    document.getElementById('notesApp').style.display = 'none';
    currentToken = null;
    localStorage.removeItem('token');
}

// Показать приложение с заметками
function showNotesApp() {
    document.getElementById('authForms').style.display = 'none';
    document.getElementById('notesApp').style.display = 'block';
    document.getElementById('userName').textContent = currentUser.username;
}

// Показать форму входа
function showLogin() {
    document.getElementById('loginForm').classList.add('active');
    document.getElementById('registerForm').classList.remove('active');
}

// Показать форму регистрации
function showRegister() {
    document.getElementById('registerForm').classList.add('active');
    document.getElementById('loginForm').classList.remove('active');
}

// Обработка входа
document.getElementById('loginFormElement').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        const response = await fetch(`${API_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        if (response.ok) {
            const data = await response.json();
            currentToken = data.access_token;
            currentUser = data.user;
            localStorage.setItem('token', currentToken);
            showNotesApp();
            loadNotes();
            showToast('Успешный вход!');
        } else {
            const error = await response.json();
            showToast(error.error || 'Ошибка входа', 'error');
        }
    } catch (error) {
        showToast('Ошибка соединения', 'error');
    }
});

// Обработка регистрации
document.getElementById('registerFormElement').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('regUsername').value;
    const email = document.getElementById('regEmail').value;
    const password = document.getElementById('regPassword').value;
    
    try {
        const response = await fetch(`${API_URL}/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, email, password })
        });
        
        if (response.ok) {
            const data = await response.json();
            currentToken = data.access_token;
            currentUser = data.user;
            localStorage.setItem('token', currentToken);
            showNotesApp();
            loadNotes();
            showToast('Регистрация успешна!');
        } else {
            const error = await response.json();
            showToast(error.error || 'Ошибка регистрации', 'error');
        }
    } catch (error) {
        showToast('Ошибка соединения', 'error');
    }
});

// Выход из системы
document.getElementById('logoutBtn').addEventListener('click', () => {
    currentToken = null;
    currentUser = null;
    localStorage.removeItem('token');
    showAuthForms();
    showToast('Вы вышли из системы');
});

// Загрузка заметок
async function loadNotes() {
    try {
        const response = await fetch(`${API_URL}/notes`, {
            headers: {
                'Authorization': `Bearer ${currentToken}`
            }
        });
        
        if (response.ok) {
            allNotes = await response.json();
            renderNotesList();
        }
    } catch (error) {
        showToast('Ошибка загрузки заметок', 'error');
    }
}

// Отображение списка заметок
function renderNotesList() {
    const notesList = document.getElementById('notesList');
    
    if (allNotes.length === 0) {
        notesList.innerHTML = '<div class="empty-state"><i class="fas fa-note-sticky"></i><p>Нет заметок</p></div>';
        return;
    }
    
    notesList.innerHTML = allNotes.map(note => `
        <div class="note-item ${currentNote?.id === note.id ? 'active' : ''}" onclick="selectNote(${note.id})">
            <div class="note-title">${escapeHtml(note.title)}</div>
            <div class="note-preview">${escapeHtml(note.content.substring(0, 50))}</div>
            <div class="note-date">${new Date(note.created_at).toLocaleDateString()}</div>
            <button class="delete-note" onclick="deleteNote(${note.id}, event)">
                <i class="fas fa-trash"></i>
            </button>
        </div>
    `).join('');
}

// Выбор заметки
async function selectNote(noteId) {
    try {
        const response = await fetch(`${API_URL}/notes/${noteId}`, {
            headers: {
                'Authorization': `Bearer ${currentToken}`
            }
        });
        
        if (response.ok) {
            currentNote = await response.json();
            showNoteEditor();
        }
    } catch (error) {
        showToast('Ошибка загрузки заметки', 'error');
    }
}

// Показать редактор заметки
function showNoteEditor() {
    const editorArea = document.getElementById('editorArea');
    
    editorArea.innerHTML = `
        <div class="note-editor fade-in">
            <input type="text" id="noteTitle" placeholder="Заголовок заметки" value="${escapeHtml(currentNote?.title || '')}">
            <textarea id="noteContent" placeholder="Текст заметки...">${escapeHtml(currentNote?.content || '')}</textarea>
            <div class="note-editor-actions">
                ${currentNote ? '<button class="btn-cancel" onclick="deleteNote(currentNote.id)">Удалить</button>' : ''}
                <button class="btn-save" onclick="saveNote()">Сохранить</button>
            </div>
        </div>
    `;
}

// Создание новой заметки
document.getElementById('newNoteBtn').addEventListener('click', () => {
    currentNote = null;
    showNoteEditor();
});

// Сохранение заметки
async function saveNote() {
    const title = document.getElementById('noteTitle').value;
    const content = document.getElementById('noteContent').value;
    
    if (!title || !content) {
        showToast('Заполните заголовок и текст заметки', 'error');
        return;
    }
    
    try {
        let response;
        
        if (currentNote) {
            // Обновление существующей заметки
            response = await fetch(`${API_URL}/notes/${currentNote.id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${currentToken}`
                },
                body: JSON.stringify({ title, content })
            });
        } else {
            // Создание новой заметки
            response = await fetch(`${API_URL}/notes`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${currentToken}`
                },
                body: JSON.stringify({ title, content })
            });
        }
        
        if (response.ok) {
            const savedNote = await response.json();
            currentNote = savedNote;
            await loadNotes();
            selectNote(savedNote.id);
            showToast('Заметка сохранена!');
        } else {
            showToast('Ошибка сохранения', 'error');
        }
    } catch (error) {
        showToast('Ошибка соединения', 'error');
    }
}

// Удаление заметки
async function deleteNote(noteId, event) {
    if (event) {
        event.stopPropagation();
    }
    
    if (!confirm('Удалить эту заметку?')) return;
    
    try {
        const response = await fetch(`${API_URL}/notes/${noteId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${currentToken}`
            }
        });
        
        if (response.ok) {
            if (currentNote && currentNote.id === noteId) {
                currentNote = null;
                document.getElementById('editorArea').innerHTML = `
                    <div class="empty-state">
                        <i class="fas fa-pen-fancy"></i>
                        <h3>Заметка удалена</h3>
                        <p>Создайте новую заметку</p>
                    </div>
                `;
            }
            await loadNotes();
            showToast('Заметка удалена');
        } else {
            showToast('Ошибка удаления', 'error');
        }
    } catch (error) {
        showToast('Ошибка соединения', 'error');
    }
}

// Вспомогательные функции
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    toast.style.background = type === 'error' ? '#f44336' : '#4caf50';
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// Экспорт функций для глобального использования
window.selectNote = selectNote;
window.deleteNote = deleteNote;
window.showLogin = showLogin;
window.showRegister = showRegister;