from functools import wraps
from flask import request, jsonify
from flask_jwt_extended import verify_jwt_in_request, get_jwt_identity
from models import User, db
from werkzeug.security import generate_password_hash, check_password_hash

def init_auth(app):
    """Инициализация JWT"""
    from flask_jwt_extended import JWTManager
    jwt = JWTManager(app)
    return jwt

def register_user(username, email, password):
    """Регистрация нового пользователя"""
    if User.query.filter_by(username=username).first():
        return None, "Username already exists"
    
    if User.query.filter_by(email=email).first():
        return None, "Email already exists"
    
    password_hash = generate_password_hash(password)
    user = User(username=username, email=email, password_hash=password_hash)
    
    db.session.add(user)
    db.session.commit()
    
    return user, "User created successfully"

def authenticate_user(username, password):
    """Аутентификация пользователя"""
    user = User.query.filter_by(username=username).first()
    
    if not user or not check_password_hash(user.password_hash, password):
        return None, "Invalid credentials"
    
    return user, "Authentication successful"

def login_required(fn):
    """Декоратор для защиты эндпоинтов"""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            verify_jwt_in_request()
            return fn(*args, **kwargs)
        except Exception as e:
            return jsonify({'error': 'Authentication required', 'message': str(e)}), 401
    return wrapper

def get_current_user():
    """Получить текущего пользователя из JWT"""
    user_id = get_jwt_identity()
    return User.query.get(user_id)