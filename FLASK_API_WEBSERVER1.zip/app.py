import os
from flask import Flask, request, jsonify, send_from_directory, render_template
from flask_cors import CORS
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity, JWTManager
from dotenv import load_dotenv
from datetime import timedelta
from functools import wraps

load_dotenv()

app = Flask(__name__, static_folder='static', template_folder='templates')
CORS(app, origins="*", supports_credentials=True)

# Конфигурация
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'sqlite:///database.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = os.getenv('JWT_SECRET_KEY', 'super-secret-key-change-this-2024')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)

# Инициализация расширений
from models import db, User, Note

db.init_app(app)
jwt = JWTManager(app)

# Создание таблиц
with app.app_context():
    db.create_all()
    print("✅ База данных инициализирована")

# ========== ВЕБ-ИНТЕРФЕЙС ==========

@app.route('/')
def index():
    """Главная страница"""
    return render_template('index.html')

@app.route('/static/<path:path>')
def serve_static(path):
    """Раздача статических файлов"""
    return send_from_directory('static', path)

# ========== АВТОРИЗАЦИЯ API ==========

@app.route('/api/register', methods=['POST'])
def register():
    """Регистрация нового пользователя"""
    try:
        data = request.get_json()
        print(f"📝 Регистрация: {data}")
        
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        
        if not all([username, email, password]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        # Проверка существования пользователя
        if User.query.filter_by(username=username).first():
            return jsonify({'error': 'Username already exists'}), 400
        
        if User.query.filter_by(email=email).first():
            return jsonify({'error': 'Email already exists'}), 400
        
        # Создание пользователя
        from werkzeug.security import generate_password_hash
        password_hash = generate_password_hash(password)
        
        user = User(username=username, email=email, password_hash=password_hash)
        db.session.add(user)
        db.session.commit()
        
        print(f"✅ Пользователь создан: ID={user.id}, username={user.username}")
        
        # СОЗДАЕМ ТОКЕН - ВАЖНО: identity ДОЛЖЕН БЫТЬ СТРОКОЙ!
        access_token = create_access_token(identity=str(user.id))
        
        return jsonify({
            'message': 'User created successfully',
            'access_token': access_token,
            'user': user.to_dict()
        }), 201
        
    except Exception as e:
        print(f"❌ Ошибка регистрации: {e}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/login', methods=['POST'])
def login():
    """Вход в систему"""
    try:
        data = request.get_json()
        print(f"🔐 Вход: {data}")
        
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': 'Username and password required'}), 400
        
        from werkzeug.security import check_password_hash
        
        user = User.query.filter_by(username=username).first()
        
        if not user or not check_password_hash(user.password_hash, password):
            return jsonify({'error': 'Invalid credentials'}), 401
        
        print(f"✅ Пользователь найден: ID={user.id}")
        
        # ВАЖНО: identity ДОЛЖЕН БЫТЬ СТРОКОЙ!
        access_token = create_access_token(identity=str(user.id))
        
        return jsonify({
            'message': 'Authentication successful',
            'access_token': access_token,
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        print(f"❌ Ошибка входа: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/me', methods=['GET'])
@jwt_required()
def get_current_user_info():
    """Получить информацию о текущем пользователе"""
    try:
        # get_jwt_identity() возвращает строку
        user_id = get_jwt_identity()
        print(f"👤 Запрос информации о пользователе ID={user_id}")
        
        user = User.query.get(int(user_id))
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        return jsonify(user.to_dict()), 200
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return jsonify({'error': str(e)}), 500

# ========== ЗАМЕТКИ API ==========

@app.route('/api/notes', methods=['GET'])
@jwt_required()
def get_notes():
    """Получить все заметки текущего пользователя"""
    try:
        user_id = get_jwt_identity()
        print(f"📋 Загрузка заметок для пользователя ID={user_id}")
        
        notes = Note.query.filter_by(user_id=int(user_id)).order_by(Note.created_at.desc()).all()
        print(f"✅ Найдено {len(notes)} заметок")
        
        return jsonify([note.to_dict() for note in notes]), 200
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/notes/<int:note_id>', methods=['GET'])
@jwt_required()
def get_note(note_id):
    """Получить конкретную заметку"""
    try:
        user_id = get_jwt_identity()
        print(f"📖 Загрузка заметки ID={note_id} для пользователя ID={user_id}")
        
        note = Note.query.filter_by(id=note_id, user_id=int(user_id)).first()
        
        if not note:
            return jsonify({'error': 'Note not found'}), 404
        
        return jsonify(note.to_dict()), 200
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/notes', methods=['POST'])
@jwt_required()
def create_note():
    """Создать новую заметку"""
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        print(f"➕ Создание заметки для пользователя ID={user_id}, данные={data}")
        
        title = data.get('title')
        content = data.get('content')
        
        if not title or not content:
            return jsonify({'error': 'Title and content are required'}), 400
        
        note = Note(title=title, content=content, user_id=int(user_id))
        db.session.add(note)
        db.session.commit()
        
        print(f"✅ Заметка создана: ID={note.id}")
        
        return jsonify(note.to_dict()), 201
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/notes/<int:note_id>', methods=['PUT'])
@jwt_required()
def update_note(note_id):
    """Обновить заметку"""
    try:
        user_id = get_jwt_identity()
        data = request.get_json()
        
        print(f"✏️ Обновление заметки ID={note_id} для пользователя ID={user_id}")
        
        note = Note.query.filter_by(id=note_id, user_id=int(user_id)).first()
        
        if not note:
            return jsonify({'error': 'Note not found'}), 404
        
        if 'title' in data:
            note.title = data['title']
        if 'content' in data:
            note.content = data['content']
        
        db.session.commit()
        
        print(f"✅ Заметка обновлена: ID={note.id}")
        
        return jsonify(note.to_dict()), 200
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/notes/<int:note_id>', methods=['DELETE'])
@jwt_required()
def delete_note(note_id):
    """Удалить заметку"""
    try:
        user_id = get_jwt_identity()
        print(f"🗑️ Удаление заметки ID={note_id} для пользователя ID={user_id}")
        
        note = Note.query.filter_by(id=note_id, user_id=int(user_id)).first()
        
        if not note:
            return jsonify({'error': 'Note not found'}), 404
        
        db.session.delete(note)
        db.session.commit()
        
        print(f"✅ Заметка удалена: ID={note_id}")
        
        return jsonify({'message': 'Note deleted successfully'}), 200
        
    except Exception as e:
        print(f"❌ Ошибка: {e}")
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# ========== ДОПОЛНИТЕЛЬНЫЕ ЭНДПОИНТЫ ==========

@app.route('/api/health', methods=['GET'])
def health_check():
    """Проверка работоспособности"""
    return jsonify({'status': 'ok', 'message': 'Server is running'}), 200

@app.route('/api/docs', methods=['GET'])
def api_documentation():
    """Документация API в JSON формате"""
    return jsonify({
        'endpoints': [
            {'method': 'POST', 'path': '/api/register', 'description': 'Register new user'},
            {'method': 'POST', 'path': '/api/login', 'description': 'Login user'},
            {'method': 'GET', 'path': '/api/me', 'description': 'Get current user info', 'auth': True},
            {'method': 'GET', 'path': '/api/notes', 'description': 'Get all notes', 'auth': True},
            {'method': 'GET', 'path': '/api/notes/{id}', 'description': 'Get note by ID', 'auth': True},
            {'method': 'POST', 'path': '/api/notes', 'description': 'Create note', 'auth': True},
            {'method': 'PUT', 'path': '/api/notes/{id}', 'description': 'Update note', 'auth': True},
            {'method': 'DELETE', 'path': '/api/notes/{id}', 'description': 'Delete note', 'auth': True}
        ]
    }), 200

if __name__ == '__main__':
    print("=" * 50)
    print("🚀 Запуск сервера...")
    print("📱 Интерфейс: http://localhost:5000")
    print("📡 API: http://localhost:5000/api")
    print("=" * 50)
    app.run(debug=True, host='0.0.0.0', port=5000)